package com.kpi.opto.connect.hcd.service;

import com.kpi.opto.connect.hcd.api.InputSeqTag;

public interface ClientReceiveService {

	public Object receiveMessage(InputSeqTag plcmessage);

}
