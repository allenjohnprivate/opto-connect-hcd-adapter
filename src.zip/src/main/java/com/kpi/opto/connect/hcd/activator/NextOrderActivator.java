/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2024 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd.activator;

/**
 * Represents an activator that sends the next order.
 *
 * @author Michael.Bletzinger
 */
public class NextOrderActivator {

	/**
	 * Creates a new instance of the {@link NextOrderActivator} class.
	 */
	public NextOrderActivator() {
		// do nothing
	}

}
