package com.kpi.opto.connect.hcd.translator;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.kpi.opto.connect.hcd.api.HcdErrorMessage;
import com.kpi.opto.connect.hcd.correlator.SimpleMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import java.io.IOException;
import java.util.*;

import static com.kpi.opto.connect.hcd.api.PlcTagnamesType.getFromValue;

@Slf4j
public class HcdMessageDeserializer extends StdDeserializer<Map<String, Long>> {

	ObjectMapper mapper = new ObjectMapper();

	private Map<String, Long> inputMap;

	public HcdMessageDeserializer() {
		super(SimpleMessage.class);
		mapper.registerModule(new JavaTimeModule());
		inputMap = new HashMap<>();
	}

	@Override
	public Map<String, Long> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
		JsonNode node = p.readValueAsTree();
		if (node.get("id") == null) {
			return new HashMap<>();
		}
		Long action = node.get("id").asLong();
		String paramsField = "params";

		switch (getFromValue(String.valueOf(action))) {
			case BOX_RELEASED_SEQ_NO -> inputMap.put(mapper.treeToValue(node.get(paramsField), String.class), action);
			case BOX_REJECTED_SEQ_NO -> inputMap.put(mapper.treeToValue(node.get(paramsField), String.class), action);
			case PALLET_COMPLETE_SEQ_NO ->
				inputMap.put(mapper.treeToValue(node.get(paramsField), String.class), action);
			case TOP_OFF_BOX_COUNT_SEQ_NO ->
				inputMap.put(mapper.treeToValue(node.get(paramsField), String.class), action);
			case NEW_ORDER_1, NEW_ORDER_2, NEW_ORDER_3, DATA_READY_1, DATA_READY_2, DATA_READY_3, BOX_RELEASED_HCD,
					BOX_RELEASED_PALLET, BOX_RELEASED_PALLET_SEQ, BOX_RELEASED_ACK, BOX_REJECTED_HCD,
					BOX_REJECTED_PALLET, BOX_REJECTED_PALLET_SEQ, BOX_REJECTED_ACK, PALLET_COMPLETE_HCD,
					PALLET_COMPLETE_PALLET, PALLET_COMPLETE_ACK, TOP_OFF_BOX_COUNT_HCD, TOP_OFF_BOX_COUNT_PALLET,
					TOP_OFF_BOX_COUNT_BOX_COUNT, TOP_OFF_BOX_COUNT_ACK, LINE_STOPPED_HCD, LINE_STOPPED_PALLET,
					LINE_STOPPED_PALLET_SEQ -> {
				return Collections.emptyMap();
			}

		}
		List<HcdErrorMessage> errors = Optional.ofNullable(node.get("errors")).map(e -> {
			try {
				return Arrays.asList(mapper.treeToValue(e, HcdErrorMessage[].class));
			}
			catch (JsonProcessingException ex) {
				log.error("error while processing {}", node.get("errors"), ex);
				return null;
			}
		}).orElse(null);

		Optional.ofNullable(errors).ifPresent(HcdErrorMessage::errors);
		return inputMap;
	}

}
