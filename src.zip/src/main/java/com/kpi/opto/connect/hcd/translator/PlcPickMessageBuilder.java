/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2024 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd.translator;

import com.kpi.opto.connect.hcd.api.KepwarePostArray;
import com.kpi.opto.connect.hcd.api.PlcPickItemPositionType;
import com.kpi.opto.connect.hcd.api.PlcPickLineItemPositionType;
import com.kpi.opto.connect.hcd.api.PlcTagnamesType;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a PLC Pick message
 *
 * @author Michael.Bletzinger
 */
@Component
public class PlcPickMessageBuilder {

	private final Integer plcMessageSize;

	private final List<Integer> payload = new ArrayList<>();

	private Integer totalItems;

	private final int itemLength = 7;

	private final int headerLength = 3;

	private final int decimalShift = 100;

	public PlcPickMessageBuilder(Integer plcMessageSize) {
		this.plcMessageSize = plcMessageSize;
		totalItems = 0;
	}

	public void initMessage(int orderId, int palletizer) {
		payload.clear();
		for (int i = 0; i < plcMessageSize; i++) {
			payload.add(0);
		}
		payload.set(PlcPickItemPositionType.ORDER_NUM.getPosition(), orderId);
		payload.set(PlcPickItemPositionType.PALLETIZER.getPosition(), palletizer);
	}

	public void addPickItem(PlcPickItem item, int quantity) {
		for (int i = 0; i < quantity; i++) {
			int startItem = headerLength + itemLength * totalItems;
			payload.set(startItem + PlcPickLineItemPositionType.LANE.getPosition(),
					Integer.valueOf(item.getLocation()));
			payload.set(startItem + PlcPickLineItemPositionType.SEQ_NUM.getPosition(), totalItems + 1);
			payload.set(startItem + PlcPickLineItemPositionType.WEIGHT.getPosition(),
					(int) Math.round(item.getWeight() * decimalShift));
			payload.set(startItem + PlcPickLineItemPositionType.HEIGHT.getPosition(),
					(int) Math.round(item.getHeight() * decimalShift));
			payload.set(startItem + PlcPickLineItemPositionType.LENGTH.getPosition(),
					(int) Math.round(item.getLength() * decimalShift));
			payload.set(startItem + PlcPickLineItemPositionType.WIDTH.getPosition(),
					(int) Math.round(item.getWeight() * decimalShift));
			payload.set(startItem + PlcPickLineItemPositionType.TOP_OFF.getPosition(),
					Boolean.TRUE.equals(item.getTopOff()) ? 1 : 0);
			totalItems++;
		}
	}

	public KepwarePostArray getMessage(PlcTagnamesType tag) {
		payload.set(PlcPickItemPositionType.TOTAL_BOXES.getPosition(), totalItems);
		return KepwarePostArray.builder().id(tag.getName()).v(payload.toString()).build();
	}

}
