/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2024 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd.api;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

/**
 * Represents a read response of a stringified array of integers
 *
 * @author Michael.Bletzinger
 */
@Getter
@ToString
@Builder
public class KepwarePostArray {

	/**
	 * tag name
	 */
	private String id;

	/**
	 * Stringified array of integers
	 */
	private String v;

}
