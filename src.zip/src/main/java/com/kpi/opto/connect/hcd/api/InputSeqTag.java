package com.kpi.opto.connect.hcd.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@Builder
@EqualsAndHashCode(callSuper = false)
@JsonPropertyOrder({ "BoxReleased.SEQ_NO", "BoxRejected.SEQ_NO", "TopOffBoxCount.SEQ_NO", "PalletComplete.SEQ_NO",
		"LineStopped.SEQ_NO" })
public class InputSeqTag {

	@JsonProperty("BoxReleased.SEQ_NO")
	private Long boxReleasedSeqNo;

	@JsonProperty("BoxRejected.SEQ_NO")
	private Long boxRejectedSeqNo;

	@JsonProperty("TopOffBoxCount.SEQ_NO")
	private Long topOffBoxCountSeqNo;

	@JsonProperty("PalletComplete.SEQ_NO")
	private Long palletCompleteSeqNo;

	@JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
	public InputSeqTag(@JsonProperty("BoxReleased.SEQ_NO") Long boxReleasedSeqNo,
			@JsonProperty("BoxRejected.SEQ_NO") Long boxRejectedSeqNo,
			@JsonProperty("TopOffBoxCount.SEQ_NO") Long topOffBoxCountSeqNo,
			@JsonProperty("PalletComplete.SEQ_NO") Long palletCompleteSeqNo) {
		this.boxReleasedSeqNo = boxReleasedSeqNo;
		this.boxRejectedSeqNo = boxRejectedSeqNo;
		this.topOffBoxCountSeqNo = topOffBoxCountSeqNo;
		this.palletCompleteSeqNo = palletCompleteSeqNo;
	}

}
