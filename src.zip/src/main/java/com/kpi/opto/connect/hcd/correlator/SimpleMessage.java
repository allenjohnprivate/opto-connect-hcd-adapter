/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2024 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd.correlator;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.jetbrains.annotations.Range;

@Builder
@JsonInclude(Include.NON_NULL)
public record SimpleMessage(@NotNull(message = "ID cannot be null") @Range(from = 2, to = 5) String id, String tstamp,
		String value) {
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
