/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2024 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd.config;

import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Represents the Rabbit MQ topics used to communicate with OPTO WES
 *
 * @author Michael.Bletzinger
 */
@Configuration
public class OptoAmqpConfiguration {

	@Bean
	DirectExchange optoOperationExchange(@Value("${hcd.exchanges.optooperation}") String exchangeName) {
		return new DirectExchange(exchangeName);
	}

	@Bean
	Queue optoOperationQueue(@Value("${hcd.exchanges.optooperation}") String queueName) {
		return QueueBuilder.durable(queueName).build();
	}

	@Bean
	Binding optoOperationBindingMessages(Queue optoOperationQueue, DirectExchange optoOperationExchange,
			@Value("${hcd.exchanges.optooperation}") String queueName) {
		return BindingBuilder.bind(optoOperationQueue).to(optoOperationExchange).with(queueName);
	}

	@Bean
	DirectExchange completionExchange(@Value("${hcd.exchanges.optocompletion}") String exchangeName) {
		return new DirectExchange(exchangeName);
	}

	@Bean
	Queue completionQueue(@Value("${hcd.exchanges.optocompletion}") String queueName) {
		return QueueBuilder.durable(queueName).build();
	}

	@Bean
	Binding completionBindingMessages(Queue completionQueue, DirectExchange completionExchange,
			@Value("${hcd.exchanges.optocompletion}") String queueName) {
		return BindingBuilder.bind(completionQueue).to(completionExchange).with(queueName);
	}

	@Bean
	DirectExchange progressExchange(@Value("${hcd.exchanges.optoprogress}") String exchangeName) {
		return new DirectExchange(exchangeName);
	}

	@Bean
	Queue progressQueue(@Value("${hcd.exchanges.optoprogress}") String queueName) {
		return QueueBuilder.durable(queueName).build();
	}

	@Bean
	Binding progressBindingMessages(Queue progressQueue, DirectExchange progressExchange,
			@Value("${hcd.exchanges.optoprogress}") String queueName) {
		return BindingBuilder.bind(progressQueue).to(progressExchange).with(queueName);
	}

	@Bean
	DirectExchange faultsExchange(@Value("${hcd.exchanges.optofaults}") String exchangeName) {
		return new DirectExchange(exchangeName);
	}

	@Bean
	Queue faultsQueue(@Value("${hcd.exchanges.optofaults}") String queueName) {
		return QueueBuilder.durable(queueName).build();
	}

	@Bean
	Binding faultsBindingMessages(Queue faultsQueue, DirectExchange faultsExchange,
			@Value("${hcd.exchanges.optofaults}") String queueName) {
		return BindingBuilder.bind(faultsQueue).to(faultsExchange).with(queueName);
	}

	@Bean
	Integer plcMessageSize(@Value("${hcd.plc.optopick.size}") Integer plcMessageSize) {
		return plcMessageSize;
	}

}
