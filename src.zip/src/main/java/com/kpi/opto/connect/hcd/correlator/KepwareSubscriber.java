/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2024 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd.correlator;

import java.time.Instant;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;

import jakarta.annotation.PostConstruct;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequiredArgsConstructor
@Slf4j
public class KepwareSubscriber {

	private final RabbitTemplate rabbitTemplate;

	@Value("${hcd.queues.kepware}")
	private String queueName;

	@PostConstruct
	public void init() {
		log.info("Started Kep-wareSubscriber: {}", rabbitTemplate);
	}

	@RabbitListener(queues = "${hcd.queues.kepware}", id = "KEP-WARE.CONSUMER")
	public void subscribed(@Valid SimpleMessage msg) {

		log.info("Received Message: {}", msg);

		rabbitTemplate.convertAndSend(queueName,
				new SimpleMessage(msg.id(), Instant.now().toString(), "Received message: " + msg.value()));

	}

}
