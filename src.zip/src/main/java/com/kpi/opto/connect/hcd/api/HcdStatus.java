package com.kpi.opto.connect.hcd.api;

import java.util.Arrays;

public enum HcdStatus {

	INPROGRESS("InProgress"), COMPLETED("Completed"), FAULT("Fault"), INVALID("InValid");

	private final String name;

	/**
	 * Create a new instance of the {@link PlcPickItemPositionType} enum.
	 */
	HcdStatus(String name) {
		this.name = name;
	}

	/**
	 * @return the {@code name}
	 */
	public String getName() {
		return name;
	}

	/**
	 * Gets the {@link HcdStatus} associated with the {@code value}.
	 * @param name used to find a {@link HcdStatus}.
	 */
	public static HcdStatus getFromValue(String name) {
		return Arrays.stream(values())
			.filter(x -> x.getName().equals(name))
			.findAny()
			.orElseThrow(() -> new IllegalArgumentException(String.format(
					"The value [%s] does not correspond to a defined [%s].", name, HcdStatus.class.getSimpleName())));
	}

}
