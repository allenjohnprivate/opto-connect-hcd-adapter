/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2024 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd.api;

import java.util.Arrays;

/**
 * Contains a list of positions for a pick line item
 *
 * @author Michael.Bletzinger
 */
public enum PlcPickLineItemPositionType {

	LANE(0, "Lane"), SEQ_NUM(1, "SeqNum"), WEIGHT(2, "Weight"), HEIGHT(3, "Height"), LENGTH(4, "Length"),
	WIDTH(5, "Width"), TOP_OFF(6, "TopOff");

	private final int position;

	private final String name;

	/**
	 * Create a new instance of the {@link PlcPickLineItemPositionType} enum.
	 */
	PlcPickLineItemPositionType(int position, String name) {
		this.position = position;
		this.name = name;
	}

	/**
	 * @return the {@code value}
	 */
	public int getPosition() {
		return position;
	}

	/**
	 * @return the {@code name}
	 */
	public String getName() {
		return name;
	}

	/**
	 * Gets the {@link PlcPickLineItemPositionType} associated with the {@code value}.
	 * @param name used to find a {@link PlcPickLineItemPositionType}.
	 */
	public static PlcPickLineItemPositionType getFromValue(String name) {
		return Arrays.stream(values())
			.filter(x -> x.getName().equals(name))
			.findAny()
			.orElseThrow(() -> new IllegalArgumentException(
					String.format("The value [%s] does not correspond to a defined [%s].", name,
							PlcPickLineItemPositionType.class.getSimpleName())));
	}

}
