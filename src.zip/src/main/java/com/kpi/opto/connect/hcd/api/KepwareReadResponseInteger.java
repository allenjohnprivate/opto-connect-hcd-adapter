/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2024 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

/**
 * Represents a read response of a single integer
 *
 * @author Michael.Bletzinger
 */
@Getter
@ToString
@AllArgsConstructor
@Builder
public class KepwareReadResponseInteger {

	/**
	 * tag name
	 */
	private String id;

	/**
	 * true means successful result
	 */
	private Boolean s;

	/**
	 * Error string if s is false
	 */
	private String r;

	/**
	 * A single integer as the return value
	 */
	private Integer v;

	/**
	 * timestamp
	 */
	private Long t;

}
