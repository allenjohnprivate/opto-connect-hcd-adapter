/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2024 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd.config;

import lombok.Getter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * Represents the properties needed for the HCD PLC
 *
 * @author Michael.Bletzinger
 */
@ConfigurationProperties(prefix = "hcd.plc")
@ConfigurationPropertiesScan
@Getter
public class HcdPlcProperties {

	/**
	 * Creates a new instance of the {@link HcdPlcProperties} class.
	 */
	public HcdPlcProperties() {
		// do nothing
	}

}
