package com.kpi.opto.connect.hcd.translator;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/iotgateway")
public class HcdController {

	// TODO

}
