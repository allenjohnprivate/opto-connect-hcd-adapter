package com.kpi.opto.connect.hcd.service;

import com.kpi.opto.connect.hcd.api.*;
import com.kpi.opto.connect.hcd.correlator.SimpleMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.time.Instant;
import java.util.*;

import static com.kpi.opto.connect.hcd.api.PlcTagnamesType.*;

@Slf4j
@Service
@ConditionalOnProperty(value = "hcd.queues.optofaults", havingValue = "true", matchIfMissing = false)
public class HcdTagValidatorService implements ClientReceiveService {

	private final Map<PlcTagnamesType, Long> allSeqNosMap;

	public HcdTagValidatorService() {
		this.allSeqNosMap = new EnumMap<>(PlcTagnamesType.class);
	}

	@RabbitListener(queues = "${hcd.queues.optofaults}")
	public Object receiveMessage(InputSeqTag plcmessage) {
		log.info("Receive message: {}", plcmessage);
		return processReadTags(plcmessage);
	}

	private Object processReadTags(InputSeqTag inputSeqTag) {
		return readInputTags(inputSeqTag);
	}

	public List<ClientMessage<Object>> readInputTags(InputSeqTag inputSeqTag) {
		log.info("message received:{}", inputSeqTag);
		List<ClientMessage<Object>> readResultsList = new ArrayList<>();

		if (ObjectUtils.isEmpty(inputSeqTag)) {
			return getErrorResponse(inputSeqTag, null, "No valid tags present");
		}

		Set<PlcTagnamesType> inputSeqNoList = getTagFromInputSeqNo(getAllSeqNo(inputSeqTag));

		if (!inputSeqNoList.isEmpty()) {
			for (PlcTagnamesType inputTag : inputSeqNoList) {
				switch (inputTag) {
					case BOX_RELEASED_SEQ_NO -> processTagSet(readResultsList,
							PlcTagnamesType.BOX_RELEASED_SEQ_NO.getName(), HcdStatus.INPROGRESS.getName());

					case BOX_REJECTED_SEQ_NO -> processTagSet(readResultsList,
							PlcTagnamesType.BOX_REJECTED_SEQ_NO.getName(), HcdStatus.FAULT.getName());

					case PALLET_COMPLETE_SEQ_NO -> processTagSet(readResultsList,
							PlcTagnamesType.PALLET_COMPLETE_SEQ_NO.getName(), HcdStatus.INPROGRESS.getName());

					case TOP_OFF_BOX_COUNT_SEQ_NO -> processTagSet(readResultsList,
							PlcTagnamesType.TOP_OFF_BOX_COUNT_SEQ_NO.getName(), HcdStatus.INPROGRESS.getName());

					default -> log.info("No valid sequence no");
				}
			}
		}
		log.info("Adapter response:{}", readResultsList);
		return readResultsList;
	}

	private void processTagSet(List<ClientMessage<Object>> readResultsList, String tagname, String status) {
		Set<SimpleMessage> returnMessageSet = new LinkedHashSet<>();
		returnMessageSet.add(constructReturnMessages(tagname, status));
		readResultsList.add(ClientMessage.builder().messageType(tagname).detail(returnMessageSet).build());
	}

	private SimpleMessage constructReturnMessages(String tagType, String value) {
		return SimpleMessage.builder()
			.id(tagType)
			.value(value)
			.tstamp(String.valueOf(Instant.now().toEpochMilli()))
			.build();
	}

	private Set<PlcTagnamesType> getTagFromInputSeqNo(Map<PlcTagnamesType, Long> inputSeqMap) {
		Set<PlcTagnamesType> returnMsg = new HashSet<>();
		returnMsg.addAll(inputSeqMap.keySet()
			.stream()
			.filter(v -> Arrays.stream(values()).anyMatch(x -> x.getName().equalsIgnoreCase(v.getName())))
			.toList()
			.stream()
			.toList());
		return returnMsg;
	}

	private Map<PlcTagnamesType, Long> getAllSeqNo(InputSeqTag inputSeqTag) {
		allSeqNosMap.put(BOX_RELEASED_SEQ_NO, inputSeqTag.getBoxReleasedSeqNo());
		allSeqNosMap.put(BOX_REJECTED_SEQ_NO, inputSeqTag.getBoxRejectedSeqNo());
		allSeqNosMap.put(PlcTagnamesType.TOP_OFF_BOX_COUNT_SEQ_NO, inputSeqTag.getTopOffBoxCountSeqNo());
		allSeqNosMap.put(PALLET_COMPLETE_SEQ_NO, inputSeqTag.getPalletCompleteSeqNo());

		return allSeqNosMap;
	}

	private List<ClientMessage<Object>> getErrorResponse(Object inputTags, String messageType, String errorMsg) {
		HcdErrorMessage kepwareError = HcdErrorMessage.builder().message(errorMsg).build();
		ClientMessage<Object> clientMessage = ClientMessage.builder()
			.detail(inputTags)
			.messageType(messageType)
			.errors(List.of(kepwareError))
			.build();
		log.info("response:{}", clientMessage);

		return List.of(clientMessage);
	}

}
