/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2023 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Represents a message wrapper for all client requests of type {@link ClientMessage}
 *
 * @author Chandra
 */
@Data
@NoArgsConstructor
@Builder
public class ClientMessage<T> {

	@JsonProperty("messageType")
	private String messageType;

	@JsonProperty("detail")
	private T detail;

	@JsonProperty("errors")
	private List<HcdErrorMessage> errors;

	@JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
	public ClientMessage(@JsonProperty("messageType") String messageType, @JsonProperty("detail") T detail,
			@JsonProperty("errors") List<HcdErrorMessage> errors) {
		this.messageType = messageType;
		this.detail = detail;
		this.errors = errors;
	}

}
