/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2024 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd.config;

import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 *
 */
@Configuration
public class KepwareAmqpConfiguration {

	/*
	 * Queues
	 *
	 */

	@Bean
	Queue plcUpdateQueue(@Value("${hcd.queues.kepware}") String queueName) {
		return QueueBuilder.durable(queueName).build();
	}
	/*
	 * Exchanges
	 *
	 */

	@Bean
	TopicExchange plcUpdateExchange(@Value("${hcd.exchanges.kepware}") String exchangeName) {
		return new TopicExchange(exchangeName);
	}

	/*
	 * Bindings
	 *
	 */
	@Bean
	Binding bindings4PlcUpdates(Queue plcUpdateQueue, TopicExchange messageExchange,
			@Value("${hcd.queues.kepware}") String queueName) {
		return BindingBuilder.bind(plcUpdateQueue).to(messageExchange).with(queueName);
	}

}
