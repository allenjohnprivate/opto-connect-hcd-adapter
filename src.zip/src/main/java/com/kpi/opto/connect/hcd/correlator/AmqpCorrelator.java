/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2024 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd.correlator;

import com.fasterxml.jackson.databind.Module;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.kpi.opto.connect.hcd.translator.HcdMessageDeserializer;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;

import java.util.HashMap;
import java.util.Map;

/**
 * Represents a correlator that processes topic notifications from the PLC via Kepware
 * <p>
 * Tags that are sent by the kepware:
 * <p>
 * dataReady1, dataReady2, dataReady3 - Notifications that indicates that an HCD level is
 * ready for the next order. Needs activator to grab and prepare the next order from the
 * repository.
 * <p>
 * BoxReleased.SEQ_NO - Notification that indicates that a box has been released. Needs to
 * be processed by an activator for progress notifications to the WES.
 * <p>
 * BoxRejected.SEQ_NO - Notification that indicates a box has failed the wetness test and
 * has been diverted. Needs to be processed by an activator for fault notifications to the
 * WES as well as progress and completion state in the repository.
 * <p>
 * PalletComplete.SEQ_NO - Notification that indicates a pallet order has been completed
 * for an HCD level. Needs to be processed by the progress activator with updates to the
 * completion state.
 * <p>
 * TopOffBoxCount.SEQ_NO - Notification that indicates that the top off count for a pallet
 * order has changed. Needs to be processed by the progress activator with updates to the
 * completion state.
 * <p>
 * LineStopped.HCD, LineStopped.PALLET, LineStopped.PALLET_SEQ_NO - Set of notifications
 * received when the line is stopped due to a box failing the dimension check. Needs to be
 * processed by an activator for fault notifications to the WES as well as progress and
 * completion state in the repository.
 *
 * @author Michael.Bletzinger
 */
@Controller
@RequiredArgsConstructor
@Slf4j
public class AmqpCorrelator {

	@Autowired
	private ApplicationContext applicationContext;

	private Map<String, Long> inputMap;

	private RabbitTemplate rabbitTemplate;

	public AmqpCorrelator(RabbitTemplate rabbitTemplate) {
		this.rabbitTemplate = rabbitTemplate;
		inputMap = new HashMap<>();
		inputMap = (Map<String, Long>) applicationContext.getBean("getInputMsgMap");
		log.info("inputMap:{}", inputMap);
	}

	@Bean
	public Module hcdMessageDeserializer() {
		SimpleModule module = new SimpleModule();
		module.addDeserializer(Map.class, new HcdMessageDeserializer());
		return module;
	}

	@RabbitListener(queues = "${hcd.queues.optofaults}")
	public void receiveMessage(SimpleMessage simpleMessage) {
		log.info("Received message:{}", simpleMessage);
	}

}
