/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2024 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.aopalliance.aop.Advice;
import org.springframework.amqp.rabbit.config.RetryInterceptorBuilder;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.retry.RejectAndDontRequeueRecoverer;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.retry.interceptor.RetryOperationsInterceptor;

/**
 *
 */
@Configuration
public class AmqpConfiguration {

	/*
	 * Messaging Template
	 *
	 */

	@Bean
	RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory, Jackson2JsonMessageConverter converter) {
		final var rabbitTemplate = new RabbitTemplate(connectionFactory);
		rabbitTemplate.setMessageConverter(converter);
		return rabbitTemplate;
	}

	/*
	 * Message Serialization
	 *
	 */

	@Bean
	Jackson2JsonMessageConverter converter(Jackson2ObjectMapperBuilder builder) {
		ObjectMapper objectMapper = builder.createXmlMapper(false).build();
		objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, true);
		return new Jackson2JsonMessageConverter(objectMapper);
	}

	/*
	 * Message Retries
	 *
	 */

	@Bean
	RetryOperationsInterceptor retries(@Value("${host.amqp.retry.initialInterval:1000}") long initialInterval,
			@Value("${host.amqp.retry.maxInterval:10000}") long maxInterval,
			@Value("${host.amqp.retry.multiplier:3.0}") double multiplier,
			@Value("${host.amqp.retry.retries:5}") int retries) {
		return RetryInterceptorBuilder.stateless()
			.backOffOptions(initialInterval, multiplier, maxInterval)
			.maxAttempts(retries)
			.recoverer(new RejectAndDontRequeueRecoverer())
			.build();
	}

	@Bean
	SimpleRabbitListenerContainerFactory retryContainerFactory(ConnectionFactory connectionFactory,
			RetryOperationsInterceptor retryInterceptor) {
		SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
		factory.setConnectionFactory(connectionFactory);
		Advice[] adviceChain = { retryInterceptor };
		factory.setAdviceChain(adviceChain);
		return factory;
	}

}
