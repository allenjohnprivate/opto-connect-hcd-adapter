/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2024 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd.translator;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

/**
 * Represents a PLC Pick Item that is a synthesis of the item master list and an OPTO pick
 * item
 *
 * @author Michael.Bletzinger
 */
@Getter
@Builder
@ToString
public class PlcPickItem {

	private final String location;

	private final Double weight;

	private final Double length;

	private final Double width;

	private final Double height;

	private final Boolean topOff;

}
