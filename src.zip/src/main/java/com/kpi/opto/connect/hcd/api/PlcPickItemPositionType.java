/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2024 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd.api;

import java.util.Arrays;

/**
 * Contains Positions for a Pick Order
 *
 * @author Michael.Bletzinger
 */
public enum PlcPickItemPositionType {

	ORDER_NUM(0, "OrderNum"), TOTAL_BOXES(1, "TotalBoxes"), PALLETIZER(2, "Palletizer");

	private final int position;

	private final String name;

	/**
	 * Create a new instance of the {@link PlcPickItemPositionType} enum.
	 */
	PlcPickItemPositionType(int position, String name) {
		this.position = position;
		this.name = name;
	}

	/**
	 * @return the {@code value}
	 */
	public int getPosition() {
		return position;
	}

	/**
	 * @return the {@code name}
	 */
	public String getName() {
		return name;
	}

	/**
	 * Gets the {@link PlcPickItemPositionType} associated with the {@code value}.
	 * @param name used to find a {@link PlcPickItemPositionType}.
	 */
	public static PlcPickItemPositionType getFromValue(String name) {
		return Arrays.stream(values())
			.filter(x -> x.getName().equals(name))
			.findAny()
			.orElseThrow(() -> new IllegalArgumentException(
					String.format("The value [%s] does not correspond to a defined [%s].", name,
							PlcPickItemPositionType.class.getSimpleName())));
	}

}
