package com.kpi.opto.connect.hcd.api;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class HcdErrorMessage {

	@JsonProperty("action")
	private String action;

	@JsonProperty("message")
	private String message;

	@JsonProperty("errors")
	private List<Object> errors;

	public static void errors(List<HcdErrorMessage> hcdErrorMessages) {
	}

}
