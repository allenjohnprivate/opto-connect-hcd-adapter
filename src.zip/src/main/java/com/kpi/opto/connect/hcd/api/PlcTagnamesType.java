/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2024 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd.api;

import lombok.Getter;

import java.util.Arrays;

/**
 * Contains List of tagnames that are used to contact the kepware REST API. Tagname will
 * be sent as part of the request as an id in the following format:
 * "CP12.ReadWriteArea.<TagName>" For GETs the id is included in the http parameter ids.
 * For example: http://localhost:230/iotgateway/read?ids=CP12.ReadWriteArea.<TagName> For
 * POST the tagname is included in the JSON body as the id field: [ {
 * "id":"CP12.ReadWriteArea.<TagName>", "v":67 } ]
 *
 * @author Michael.Bletzinger
 */
@Getter
public enum PlcTagnamesType {

	/**
	 * Tag which receives the Pick Order. Sent via a POST 1-3 indicate the HCD levels
	 */
	NEW_ORDER_1("NewOrder1"), NEW_ORDER_2("NewOrder2"), NEW_ORDER_3("NewOrder3"),
	/**
	 * Tag which indicates that the PLC is ready for a pick order for the level 1 = ready,
	 * 0 = not ready This tag comes in via the AMQP topic
	 */
	DATA_READY_1("DataReady1"), DATA_READY_2("DataReady2"), DATA_READY_3("DataReady3"),
	/**
	 * Set of tags that define an object that identifies a box has been released
	 * <p>
	 * SEQ_NO the queue record identifier set by the PLC. This tag comes in via the AMQP
	 * topic HCD the level number read via a GET
	 * <p>
	 * PALLET the pallet order identifier read via a GET
	 * <p>
	 * PALLET_SEQ the box sequence number read via a GET
	 * <p>
	 * ACK writing the record id (SEQ_NO) via a POST tells the PLC you are done with this
	 * record
	 */
	BOX_RELEASED_SEQ_NO("BoxReleased.SEQ_NO"), BOX_RELEASED_HCD("BoxReleased.HCD"),
	BOX_RELEASED_PALLET("BoxReleased.PALLET"), BOX_RELEASED_PALLET_SEQ("BoxReleased.PALLET_SEQ_NO"),
	BOX_RELEASED_ACK("BoxReleased.ACK"),
	/**
	 * Set of tags that define an object that identifies a box that has failed the wet
	 * check. Same fields as box released
	 */
	BOX_REJECTED_SEQ_NO("BoxRejected.SEQ_NO"), BOX_REJECTED_HCD("BoxRejected.HCD"),
	BOX_REJECTED_PALLET("BoxRejected.PALLET"), BOX_REJECTED_PALLET_SEQ("BoxRejected.PALLET_SEQ_NO"),
	BOX_REJECTED_ACK("BoxRejected.ACK"),
	/**
	 * Set of tags that define an object identifying a pallet that has been completed.
	 * Fields represent the same except no need for the box sequence number
	 */
	PALLET_COMPLETE_SEQ_NO("PalletComplete.SEQ_NO"), PALLET_COMPLETE_HCD("PalletComplete.HCD"),
	PALLET_COMPLETE_PALLET("PalletComplete.PALLET"), PALLET_COMPLETE_ACK("PalletComplete.ACK"),
	/**
	 * Set of tags that defines an object which contains the top off count.
	 * <p>
	 * SEQ_NO the record id that is sent via the AMQP topic
	 * <p>
	 * HCD the level number read with a GET
	 * <p>
	 * PALLET the pallet order identifier read with a GET
	 * <p>
	 * BOX_COUNT the top off count. Read with a GET
	 * <p>
	 * ACK the tag that you write the record id via POST to once you are done reading
	 */
	TOP_OFF_BOX_COUNT_SEQ_NO("TopOffBoxCount.SEQ_NO"), TOP_OFF_BOX_COUNT_HCD("TopOffBoxCount.HCD"),
	TOP_OFF_BOX_COUNT_PALLET("TopOffBoxCount.PALLET"), TOP_OFF_BOX_COUNT_BOX_COUNT("TopOffBoxCount.BOX_COUNT"),
	TOP_OFF_BOX_COUNT_ACK("TopOffBoxCount.ACK"),
	/**
	 * Set of tags that defines an object which identifies the reason that the line has
	 * stopped. All of these fields come via the AMQP topic
	 * <p>
	 * HCD the level number
	 * <p>
	 * PALLET the pallet order id
	 * <p>
	 * PALLET_SEQUENCE the sequence number of the box that failed the dimension check
	 */
	LINE_STOPPED_HCD("LineStopped.HCD"), LINE_STOPPED_PALLET("LineStopped.PALLET"),
	LINE_STOPPED_PALLET_SEQ("LineStopped.PALLET_SEQ_NO");

	/**
	 * -- GETTER --
	 * @return the {@code name}
	 */
	private final String name;

	/**
	 * Create a new instance of the {@link PlcTagnamesType} enum.
	 */
	PlcTagnamesType(String name) {
		this.name = name;
	}

	/**
	 * Gets the {@link PlcTagnamesType} associated with the {@code value}.
	 * @param name used to find a {@link PlcTagnamesType}.
	 */
	public static PlcTagnamesType getFromValue(String name) {
		return Arrays.stream(values())
			.filter(x -> x.getName().equals(name))
			.findFirst()
			.orElseThrow(() -> new IllegalArgumentException(
					String.format("The value [%s] does not correspond to a defined [%s].", name,
							PlcTagnamesType.class.getSimpleName())));
	}

}
