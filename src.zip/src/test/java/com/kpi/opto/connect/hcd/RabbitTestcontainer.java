package com.kpi.opto.connect.hcd;

import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.RabbitMQContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

/**
 * Creates Testcontainers for RabbitMQ for testing purposes.
 *
 */
@Testcontainers
public interface RabbitTestcontainer {

	@Container
	@ServiceConnection
	RabbitMQContainer rabbit = new RabbitMQContainer(DockerImageName.parse("rabbitmq:3.7.25-management-alpine"));

	@DynamicPropertySource
	static void registerProperties(DynamicPropertyRegistry registry) {
		rabbit.start();
		registry.add("host.amqp.enabled", () -> "true");
		registry.add("spring.rabbitmq.host", rabbit::getHost);
		registry.add("spring.rabbitmq.host", rabbit::getAmqpPort);
		registry.add("spring.rabbitmq.username", rabbit::getAdminUsername);
		registry.add("spring.rabbitmq.password", rabbit::getAdminPassword);
	}

}
