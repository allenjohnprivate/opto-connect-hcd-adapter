/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2024 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Instant;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.test.context.ActiveProfiles;

import com.kpi.opto.connect.hcd.correlator.SimpleMessage;

import lombok.extern.slf4j.Slf4j;

/**
 * Represents a {@link HcdAdapterApplication} test.
 */
@SpringBootTest
@ActiveProfiles(value = "test")
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@Slf4j
class HcdAdapterApplicationTest implements RabbitTestcontainer {

	@Autowired
	private RabbitTemplate rabbitTemplate;

	@Autowired
	AmqpAdmin amqpAdmin;

	@Value("${hcd.queues.kepware}")
	String queueName;

	@BeforeAll
	void beforeAll() {
		log.info("RabbitMQ {}:{} @{}/{}", rabbit.getHost(), rabbit.getAmqpPort(), rabbit.getAdminUsername(),
				rabbit.getAdminPassword());

		amqpAdmin.purgeQueue(queueName);

		log.info("RabbitMQ Test For kep-ware BeforeAll finished");
	}

	@Test
	void sendBasicMessageTest() throws InterruptedException {

		log.info("Starting RabbitMQ Test");

		SimpleMessage sm = new SimpleMessage("0987654321", Instant.now().toString(),
				"This is a simple test of the messaging system.");

		log.info("RabbitMQ Test  Message: {}", sm);

		rabbitTemplate.convertAndSend(queueName, sm);

		log.info("RabbitMQ Test  message sent");

		SimpleMessage msg = rabbitTemplate.receiveAndConvert(queueName, 5000l,
				new ParameterizedTypeReference<SimpleMessage>() {
				});

		log.info("RabbitMQ Test Response: {}", msg);

		assertEquals(sm.id(), msg.id());
		assertTrue(msg.value().startsWith("Received message: "));
		assertTrue(msg.value().contains(sm.value()));
		assertNotEquals(sm.tstamp(), msg.tstamp());

		log.info("RabbitMQ Test Done!");

	}

}
