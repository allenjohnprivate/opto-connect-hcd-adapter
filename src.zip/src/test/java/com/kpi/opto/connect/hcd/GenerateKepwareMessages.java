/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2024 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.opto.connect.hcd;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.kpi.opto.connect.hcd.api.KepwarePostArray;
import com.kpi.opto.connect.hcd.api.PlcTagnamesType;
import com.kpi.opto.connect.hcd.translator.PlcPickItem;
import com.kpi.opto.connect.hcd.translator.PlcPickMessageBuilder;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Represents an example application to generate JSON messages
 *
 * @author Michael.Bletzinger
 */
public class GenerateKepwareMessages {

	private final ObjectWriter ow;

	private final Path plcPickFilepath;

	private Path boxReleasedFilepath;

	private Path boxRejectedFilepath;

	private Path palletCompleteFilepath;

	private Path TopOffCountFilepath;

	private Path lineStoppedFilepath;

	/**
	 * Creates a new instance of the {@link GenerateKepwareMessages} class.
	 */
	public GenerateKepwareMessages() {
		ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
		plcPickFilepath = Paths.get(System.getProperty("user.dir"), "plcPick.json");
		boxReleasedFilepath = Paths.get(System.getProperty("user.dir"), "released.json");
		boxRejectedFilepath = Paths.get(System.getProperty("user.dir"), "rejected.json");
		palletCompleteFilepath = Paths.get(System.getProperty("user.dir"), "complete.json");
		TopOffCountFilepath = Paths.get(System.getProperty("user.dir"), "topoff.json");
		lineStoppedFilepath = Paths.get(System.getProperty("user.dir"), "stop.json");

	}

	public static void main(String[] args) {
		GenerateKepwareMessages test = new GenerateKepwareMessages();
		try {
			test.ow.writeValue(test.plcPickFilepath.toFile(), test.generatePickMessage());
		}
		catch (IOException e) {
			System.out.printf("Error writing to file %s%n", test.plcPickFilepath.toString());
		}
	}

	public KepwarePostArray generatePickMessage() {
		return generatePickContents().getMessage(PlcTagnamesType.NEW_ORDER_1);
	}

	public PlcPickMessageBuilder generatePickContents() {
		PlcPickMessageBuilder builder = new PlcPickMessageBuilder(598);
		builder.initMessage(112, 1);
		builder.addPickItem(PlcPickItem.builder()
			.location("24")
			.weight(34.12)
			.height(4.5)
			.length(7.88)
			.width(12.24)
			.topOff(false)
			.build(), 6);
		builder.addPickItem(PlcPickItem.builder()
			.location("43")
			.weight(22.4)
			.height(7.0)
			.length(15.88)
			.width(8.77)
			.topOff(false)
			.build(), 9);
		builder.addPickItem(PlcPickItem.builder()
			.location("1")
			.weight(15.33)
			.height(9.11)
			.length(7.88)
			.width(6.5)
			.topOff(false)
			.build(), 3);
		builder.addPickItem(PlcPickItem.builder()
			.location("5")
			.weight(26.12)
			.height(9.5)
			.length(10.88)
			.width(4.24)
			.topOff(true)
			.build(), 4);
		return builder;
	}

}
